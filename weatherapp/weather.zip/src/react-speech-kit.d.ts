declare module 'react-speech-kit';
